import React from 'react'

const Bind = props =>{
    return(
        <div>
            <input type="text" onChange={ props.change }>
            </input>
        </div>
    )
}
export default Bind;