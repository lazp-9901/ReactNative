const isEven = (n)=>{
    return new Promise(function(resolve,reject){
        if(typeof(n)=="number")
        {
            resolve(n);
            n%2==0?console.log(n+" là số chẵn") : console.log(n+" là số lẻ");
        }
        else
            reject("Không phải là số ");
    })
    
    
}
//ý a
const exa = ()=>{
    isEven(1);
    isEven(2);
    console.log("Hết ý a \n\n");

 }
//ý b
const exb1 = ()=>{
    console.log("kiểm tra tuần tự dãy 1,2,3 không dùng mảng");
    isEven(1).then(function(n){
        return ++n; 
    }).then(function(n){
        n%2==0?console.log(n+" là số chẵn") : console.log(n+" là số lẻ");
        return ++n;
    }).then(function(n){
        n%2==0?console.log(n+" là số chẵn") : console.log(n+" là số lẻ");
    }).catch(function(error){
        console.log(error);
    });

}
    
const exb2 = ()=>{
    console.log("Khiểm tra bằng vòng white với mảng [1,'a',2]");
    var arr = [1,'a',2];
    let i =0;
    while(i<arr.length){
        isEven(arr[i]).then(function(n){
    }).catch(function(error){
        console.log(error);
    })
        ++i;
    }
}



//ý c

const exc1 = ()=>{
    //day 1,2,3
    Promise.all([isEven(1),isEven(2),isEven(3)])
    .then(function(result){
        console.log(result)
    })
}

const exc2 = ()=>{
    //day 1,'a',2
    Promise.all([isEven(1),isEven('a'),isEven(2)])
    .then(function(result){
    console.log(result)
    }).catch(function(error){
    console.log(error);
    })
}


//ý d
const exd1 = ()=>{
    //kiểm tra các số 1,2,3
    const taskD1 = async()=>{
        const promas = await Promise.all([isEven(1),isEven(2),isEven(3)])
        return promas;
    }
    taskD1().then(function(value){
        console.log(value);
    }).catch(function(error){
        console.log(error);
    })
}

const exd2 = ()=>{
    //kiểm tra các số 1,'a',2
    const taskD2 = async()=>{
        const promas = await Promise.all([isEven(1),isEven(2),isEven(3)])
        return promas;
    }
    taskD2().then(function(value){
        console.log(value);
    }).catch(function(error){
        console.log(error);
    })

}


//ý e
const exe = ()=>{
    const taskD = async()=>{
    const promas = await Promise.all([isEven(1),isEven('a'),isEven(2)])
    return promas;
}
taskD().then(function(value){
    console.log(value);
}).catch(function(error){
    console.log(error);
}).finally(function(){
    console.log("Đã kiểm tra");
})

}

exa();
// exb1();
//exb2();
// exc2();
// exd1();
// exd2();
exe();