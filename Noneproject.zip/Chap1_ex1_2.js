//Bai1
class Book{
    //Neu sach da xuat ban param daXB nhan gia tri la 1 , neu chua xuat ban thi gia tri la 0 
    constructor(id,tenSach,tacGia,ngayXB,giaBia,dangXB){
        this.id = id;
        this.tenSach = tenSach;
        this.tacGia = tacGia;
        this.ngayXB = ngayXB;
        this.giaBia = giaBia;
        this.dangXB = dangXB;
    }
    books = [];
    //them sach
    addBook(tenSach,tacGia,ngayXB,giaBia,dangXB){
        var book = new Book(this.books.length+1,tenSach,tacGia,ngayXB,giaBia,dangXB);
        this.books.push(book);
    }
    //lay ra tat ca cac quyen sach
    takeBook(){
        let i = 0;
        while(i<this.books.length)
        {
            console.log("id : "+ this.books[i].id);
            console.log("Tên sách : "+ this.books[i].tenSach);
            console.log("Tên tác giả : "+ this.books[i].tacGia);
            console.log("Ngày xuất bản : "+ this.books[i].ngayXB);
            console.log("Giá bán : "+ this.books[i].giaBia);
            console.log("Còn xuất bản(1:có/0:không) : "+ this.books[i].dangXB+ "\n\n");
            i++;
        }
    }
    //lay sach co id truyen vao
    takeBookID(id){
        var xh = 0;
        for(var i=0;i<this.books.length-1;i++){
            if(this.books[i].id==id){
                console.log("id : "+ this.books[i].id);
                console.log("Tên sách : "+ this.books[i].tenSach);
                console.log("Tên tác giả : "+ this.books[i].tacGia);
                console.log("Ngày xuất bản : "+ this.books[i].ngayXB);
                console.log("Giá bán : "+ this.books[i].giaBia);
                console.log("Còn xuất bản(1:có/0:không) : "+ this.books[i].dangXB+ "\n\n");
                xh = 1;
            }
        }                
        if(xh=0)
            console.log("idNotFound");
    }
    //xoa quyen sach co id truyen vao
    deleteBook(id){
        for(var i=0; i<this.books.length;i++){
            if(this.books[i].id==id)
                this.books.splice(i,1);        
        }
    }

    isStillPublished(){
        for(var i=0; i<this.books.length;i++){
            if(this.books[i].dangXB==1){
                console.log("id : "+ this.books[i].id);
                console.log("Tên sách : "+ this.books[i].tenSach);
                console.log("Tên tác giả : "+ this.books[i].tacGia);
                console.log("Ngày xuất bản : "+ this.books[i].ngayXB);
                console.log("Giá bán : "+ this.books[i].giaBia);
                console.log("Còn xuất bản(1:có/0:không) : "+ this.books[i].dangXB+ "\n\n");
            }        
        }
    }
    getNameDate(){
        for(var i=0; i<this.books.length;i++){
            console.log("Name: "+this.books[i].tenSach,"\nPublished date: "+this.books[i].ngayXB);
        }
    }
    //Truyen vao ten sach hoac ten tac gia va ham se tra ve cac cuon sach cos thog tin tuong ung
    filterByName(ten){
        var i=0;
        var xh = 0;
        while(i<this.books.length){
            var tenSach = this.books[i].tenSach;
            var tenTG = this.books[i].tacGia;
            var subString = ten;
            if(tenSach.includes(subString) || tenTG.includes(subString)){
                console.log("id : "+ this.books[i].id);
                console.log("Tên sách : "+ this.books[i].tenSach);
                console.log("Tên tác giả : "+ this.books[i].tacGia);
                console.log("Ngày xuất bản : "+ this.books[i].ngayXB);
                console.log("Giá bán : "+ this.books[i].giaBia);
                console.log("Còn xuất bản(1:có/0:không) : "+ this.books[i].dangXB+ "\n\n");
                var xh = 1;
                
            }
            i++;
        }
        if(xh==0){
            console.log("isNotFound");
        }
    }
    totalPrice(){
        var i=0;
        var price =0;
        while(i<this.books.length){
            price+=this.books[i].giaBia;
            i++;
        }
        console.log(price);
    }
}
// Bai 2
var bookDemo = new Book;
//y a
const parta = ()=>{
    bookDemo.addBook("Sach 1","Tac gia A","2/3/1850",120000,0);
    bookDemo.addBook("Sach 2","Tac gia B","3/4/1950",40000,0);
    bookDemo.addBook("Sach 3","Tac gia C","4/5/2021",250000,1);
    bookDemo.addBook("Tôi thấy hoa vàng trên cỏ xanh","Nguyễn Nhật Ánh","9/12/2010",250000,1);
    bookDemo.addBook("Sach 5","Tac gia E","6/7/2020",100000,1);
// bookDemo.addBook("nguyen","Tac gia E","6/7/2020",100000,1);
}

//y b
const partb = ()=>{
    console.log("Lấy ra cuốn sách có id = 3:");
    bookDemo.takeBookID(3);
    console.log("Lấy ra cuốn sách mà trong tên sách hoặc tên tác giả chứa chữ n:")
    bookDemo.filterByName("n");
    console.log("Lấy ra cuốn sách đã xuất bản:")
    bookDemo.isStillPublished();
}
//y c
const partc = ()=>{
    console.log("Tổng giá bìa của các cuốn sách:");
    bookDemo.totalPrice()
}

//test
parta();
partb();
partc();
