import './App.css';
//import Bind from './components/bind';
import List from './components/list'

function App() {
  return (
    <div className="App">
      <h1>Hoc ReacNative</h1>
    </div>
  );
}
const changeByLetter = (e) => {
  this.setState({
    animals:[
      { name: e.target.value }
    ]
  })
const student1 = {
  name : 'Sarah',
  age : 19,
  role : 'Student'
}
const student2 = {
  name : 'Janime',
  age : 43,
  role : 'Professor'
}
const student3 = {
  name : 'William',
  age : 27,
  role : 'Associate Professor'
}
const Student = [];
Student.push(student1);
  return (
    <div>
      {/* <Bind
      name={ this.state.animals.name }
      change={ this.changeByLetter }/> */}
      <List 
      listStudent={this.Student}
      />
      this.Student;
    </div>
    )
}

export default App;
