() => {
    const [count, setCount] = useState(0)
    const handleClick = () => setCount(count + 1)
  
    useEffect(() => {
      document.title = 'Count is: ' + count
    },[count])
  
    return <div>
      <p>Để title trang web để nhận thấy thay đổi</p>
      <button onClick={handleClick}>Increment Count</button>
    </div>
  }