import React from "react";

const list = (props) =>{
    const students = props.listStudent;
    const listStudents = students.map((student)=>{
        <li>student</li>
    });
    return(
        <ul>listStudents</ul>
    );
    console.log("test");

}
export default list;